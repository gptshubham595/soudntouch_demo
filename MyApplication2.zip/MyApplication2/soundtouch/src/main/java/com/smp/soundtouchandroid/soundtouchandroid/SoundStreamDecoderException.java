package com.smp.soundtouchandroid.soundtouchandroid;


public class SoundStreamDecoderException extends Exception
{
	public SoundStreamDecoderException(String errorMsg)
	{
		super(errorMsg);
	}
}
