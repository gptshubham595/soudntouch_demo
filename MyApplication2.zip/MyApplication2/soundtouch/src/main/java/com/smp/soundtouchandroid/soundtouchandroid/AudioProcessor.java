package com.smp.soundtouchandroid.soundtouchandroid;

public interface AudioProcessor
{

}
