package com.smp.soundtouchandroid;

public class SoundStreamRuntimeException extends RuntimeException
{
	public SoundStreamRuntimeException(String errorMsg)
	{
		super(errorMsg);
	}

	private static final long serialVersionUID = -772966743102678592L;
	
}
