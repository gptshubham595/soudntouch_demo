package com.smp.soundtouchandroid;

public interface AudioProcessor
{

}
